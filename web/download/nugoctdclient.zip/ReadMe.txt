Fill in the properties.settings file with the correct parameters.
These contain the passwords for the webservice and the sftp channel.

Examples for implementation in java are found at:
http://nbx13.nugo.org/ctd