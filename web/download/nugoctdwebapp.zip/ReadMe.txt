Fill in the properties.settings file with the correct parameters.
It is located in the WEB-INF/classes folder.
Among other things, it contains the webservice password which needs to 
be similar to the password located at the client.
Also the databasename, username and password of a local MySQL server 
are defined here.

Download the Rscript and the sql files from the webpage.

Directions for installation on the TomCat webserver are found at:
http://nbx13.nugo.org/ctd